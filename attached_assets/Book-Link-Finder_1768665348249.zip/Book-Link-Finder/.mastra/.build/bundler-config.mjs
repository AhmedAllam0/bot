const bundler = {
  externals: ["@slack/web-api", "inngest", "inngest/hono", "hono", "hono/streaming"],
  sourcemap: true
};

export { bundler };
